package sample.selendroid.project.selenapp;

import io.selendroid.SelendroidCapabilities;
import io.selendroid.SelendroidConfiguration;
import io.selendroid.SelendroidDriver;
import io.selendroid.SelendroidLauncher;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

/**
 * Base Test to demonstrate how to test native android apps with Selendroid. App under test is:
 * src/main/resources/selendroid-test-app-0.9.0.apk
 * 
 * @author ddary
 */
public class SecondUserRegistrationTest {
	private static SelendroidLauncher selendroidServer;
	private static SelendroidDriver driver;
	
	@BeforeClass
	public static void setUp() throws Exception {
		SelendroidConfiguration config = new SelendroidConfiguration();
		config.addSupportedApp("src/test/resources/selendroid-test-app-0.9.0.apk");
		selendroidServer = new SelendroidLauncher(config);
		selendroidServer.lauchSelendroid();		
		SelendroidCapabilities caps = new SelendroidCapabilities("io.selendroid.testapp:0.9.0");
		driver = new SelendroidDriver(caps);
	}

  @Test
  public void assertUserAccountCanRegistered() throws Exception {
    // Initialize test data
    UserDO user = new UserDO("u$erNAme", "me@myserver.com", "mySecret", "John Doe", "Python");

    registerUser(user);
    verifyUser(user);
  }

  private void registerUser(UserDO user) throws Exception {
    driver.get("and-activity://io.selendroid.testapp.RegisterUserActivity");

    WebElement username = driver.findElement(By.id("inputUsername"));
    username.sendKeys(user.username);

    driver.findElement(By.name("email of the customer")).sendKeys(user.email);
    driver.findElement(By.id("inputPassword")).sendKeys(user.password);

    WebElement nameInput = driver.findElement(By.xpath("//EditText[@id='inputName']"));
    Assert.assertEquals(nameInput.getText(), "Mr. Burns");
    nameInput.clear();
    nameInput.sendKeys(user.name);

    driver.findElement(By.tagName("Spinner")).click();
    driver.findElement(By.linkText(user.programmingLanguage)).click();

    driver.findElement(By.className("android.widget.CheckBox")).click();

    driver.findElement(By.linkText("Register User (verify)")).click();
    Assert.assertEquals(driver.getCurrentUrl(), "and-activity://VerifyUserActivity");
  }

  private void verifyUser(UserDO user) throws Exception {
    Assert.assertEquals(driver.findElement(By.id("label_username_data")).getText(), user.username);
    Assert.assertEquals(driver.findElement(By.id("label_email_data")).getText(), user.email);
    Assert.assertEquals(driver.findElement(By.id("label_password_data")).getText(), user.password);
    Assert.assertEquals(driver.findElement(By.id("label_name_data")).getText(), user.name);
    Assert.assertEquals(driver.findElement(By.id("label_preferedProgrammingLanguage_data"))
        .getText(), user.programmingLanguage);
    Assert.assertEquals(driver.findElement(By.id("label_acceptAdds_data")).getText(), "true");
  }

	@After
	public void tearDown() {
		driver.quit();
	}
	
	@AfterClass
	public static void shutDown() {
		selendroidServer.stopSelendroid();
	}
}