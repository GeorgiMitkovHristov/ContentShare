package sample.selendroid.project.selenapp;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ UserRegistrationTest.class,
	SecondUserRegistrationTest.class,
	ThirdUserRegistrationTest.class,
	FourthRegistrationTest.class,
	FifthUserRegistrationTest.class})
public class AllTests {

}
