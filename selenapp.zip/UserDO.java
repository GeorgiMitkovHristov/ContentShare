package sample.selendroid.project.selenapp;

public class UserDO {

	public CharSequence username;
	public CharSequence email;
	public CharSequence password;
	public CharSequence name;
	public String programmingLanguage;

	public UserDO(String string, String string2, String string3,
			String string4, String string5) {
		username = string;
		email = string2;
		password = string3;
		name = string4;
		programmingLanguage = string5;
		// TODO Auto-generated constructor stub
	}

}
